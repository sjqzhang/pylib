version_info = (3, 0, 0, 'rc1')
version = '3.0.0'
release = '3.0.0rc1'

__version__ = release  # PEP 396
