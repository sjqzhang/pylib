from setuptools import setup

setup(
    name='TopoRequires4',
    version='0.0.1',
    packages=['toporequires4'],
    install_requires=['TopoRequires2', 'TopoRequires', 'TopoRequires3'],
)
