from setuptools import setup

setup(
    name='TopoRequires',
    version='0.0.1',
    packages=['toporequires'],
)
