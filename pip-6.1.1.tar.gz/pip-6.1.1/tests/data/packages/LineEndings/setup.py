from distutils.core import setup

setup()
