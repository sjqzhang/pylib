This directory has the odd space in its name in order to test urlquoting and
dequoting of file:// scheme index URLs.
