from distutils.core import setup

setup(
    name='mlogging',
    version='0.1',
    description='logging handler for the multiprocess',
    author='Kies Lee',
    author_email='lleelm@gmail.com',
    packages=['mlogging'],
    )
